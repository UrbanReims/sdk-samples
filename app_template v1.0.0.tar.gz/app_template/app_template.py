# Ericsson Cradlepoint SDK Application
import cp
cp.log('Starting...')
