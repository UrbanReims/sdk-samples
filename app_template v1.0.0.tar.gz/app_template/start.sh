#!/bin/bash
cppython app_template.py